# Bezier Pen for Aseprite — English 0.18.2

An independent editor for Bezier paths and vector shapes, with pixel output and editable path data stored in your Aseprite file. This English edition matches Traditional Chinese 0.18.2.

## Install

Open the included `.aseprite-extension` in Aseprite and install it, then restart Aseprite. Tested with Aseprite 1.3.18.3 on Windows. Open an RGB sprite and use the layer/cel context-menu commands **Bezier Pen: New path...** or **Bezier Pen: Edit this path...**. The commands can also be assigned shortcuts in Aseprite's Keyboard Shortcuts dialog.

This edition uses the same extension ID and saved-data format as the Chinese edition. Install one language at a time; installing English replaces the Chinese edition. Existing path data and user-defined names remain compatible. Keep the PNG files in `icons/` when distributing source; they load relative to the extension folder.

## Drawing and editing

- Pen: click to add anchors; drag to create handles. Click an open endpoint to continue; click another endpoint to join. Joining the ends of one subpath closes it. Escape ends the current continuation; Start new subpath begins a disconnected curve in the same path item.
- Add point: insert on a segment while preserving its shape. Remove point: remove an anchor and reconnect its neighbors. Delete or Delete selected anchors removes the selected points and breaks the remaining curve at the gap.
- Select and Move point: drag on blank space to box-select anchors; drag inside the selection box to move them. Move point also edits individual anchors and handles. Alt allows independent handle adjustment.
- Drag selection-box handles to scale; drag the upper rotation handle to rotate. Shift keeps proportional scaling or snaps rotation. Ctrl scales around the center.
- Shift-click another shape to select additional items from Current path, within the same Aseprite layer. Use their shared box to move, scale or rotate together. Other operations, including color, width, copy/cut and deletion, still affect the current path. Select a path from the menu to return to individual editing.
- Ctrl+C / Ctrl+X / Ctrl+V copy, cut and paste selected anchors. Existing connections are preserved; disconnected points stay disconnected. Paste appends subpaths to the current item, including between files while Aseprite remains open. It is an internal curve clipboard, not an SVG or system clipboard.

## Shapes and appearance

Drag to create lines, rectangles, ellipses, triangles, polygons and stars. Set polygon/star point count and star depth before drawing. Shift constrains proportions; lines snap to 45-degree directions. Shapes become editable Bezier anchors after creation.

Corner radius rounds straight corners on eligible shapes. Round selected corners also works on selected sharp joins between straight pen segments. Curved joins and endpoints are excluded. Rounding changes geometry; it is not a retained shape parameter. Lines use round stroke ends; ellipse geometry uses cubic Bezier approximations.

Enable Stroke or Fill to show their settings. Select anchors to color their connected subpaths; without selected anchors, colors edit the path default. Stroke width and dash style are shared by a path item; Anchor width controls local width. Dashed strokes use four alternating lengths: gap, ink, gap, ink. Custom strokes are reserved for a future version.

Linked mirrors follow a source path. Edit the source or unlink to edit the mirror independently. Custom axes are supported. Path names and ordering control organization and overlap.

## Frames, resizing and recovery

Curve data is stored per frame. Copy previous frame copies curves into the current editor. Apply changes only the frame opened for editing. Close the editor before switching or rearranging timeline frames, then reopen on the desired frame.

When saved curve dimensions differ from the canvas, choose Scale to new size or Move only. Move only preserves curve size, handles and stroke width. The nine alignment buttons position the old canvas relative to the new one; Extra X/Y sliders add offsets. Positive X moves right, positive Y moves down.

The resize preview shows blue curve outlines, including off-canvas geometry, and a yellow bounding box. Drag inside the yellow box in Move only mode to position all curves. Fit artwork + curves finds everything; Fit canvas shows just the artwork. Use the zoom field, wheel, 100% button and middle-button drag (or Space+left drag) to navigate. Preview navigation does not alter curve geometry. Continue editing is not a commit: Apply writes the result to the current frame. Cancel leaves saved data unchanged.

Preferences controls editing limits and automatic recovery backups. Auto-save stores unapplied curve drafts at the chosen minute/second interval in Aseprite's user configuration folder. It does not save the complete sprite. Load backup restores a draft for review; Apply commits it. Save your `.aseprite` document normally to retain the applied pixels and embedded curve data.

## Limits and validation

The editor produces raster pixels in Aseprite; it is not a native vector layer or SVG editor. Editing requires RGB mode. Cross-selection is within plugin path items, not across timeline layers. Very large paths, wide strokes and extreme zoom may be expensive. Resizing is resolved separately when each frame is opened. Curve outlines and selection boxes never appear in the applied artwork.

English automated checks passed for shapes, colors involved in shape output, selection, shared transforms, undo/redo, path names/order, saved output, resizing, off-canvas bounds, drag offsets and preview navigation. Actual English dialog layout still needs user testing on different display scales.

License: MIT; see LICENSE. Icons are included with this package.
